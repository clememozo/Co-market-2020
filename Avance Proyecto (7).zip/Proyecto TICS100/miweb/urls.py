from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name= "index"),
    path('Foro', views.foro, name= "foro"),
    path('Mercado', views.mercado, name = "mercado"),
    path('add',views.add, name= "add"),
    path('Formulario', views.Formulario, name= "Formulario")
]