from django.db import models


class Mercado(models.Model):

    Nombre = models.CharField(max_length=100)
    Telefono =  models.CharField(max_length=100)
    Correo = models.CharField(max_length=20)
    Lugar = models.CharField(max_length=12)
    Precio= models.CharField(max_length=12)
    Descripcion = models.TextField()
    
    def publish(self):
        self.save()
