from django.shortcuts import render, HttpResponse
from .models import Mercado
def index(request):
    return render(request, "index.html")

def foro(request):
    if request.method == 'POST':
        print('Ho')
    return render(request, "foro.html")
    

def mercado(request):
    return render(request, "mercado.html")

def add(request):
    return render(request, 'add.html')

def Formulario(request):
    if request.method == "POST":
        Nombre= request.POST["Nombre"]
        Telefono= request.POST["Telefono"]
        Correo= request.POST["Correo"]
        Lugar= request.POST["Lugar"]
        Precio= request.POST["Precio"]
        Descripcion= request.POST["Descripcion"]

        
        if (Nombre == '' or Telefono=='' or Correo=='' or Lugar=='' or Precio=='' or Descripcion==''):
            return render(request, 'mercado.html')
        else:
            nuevo_articulo = Mercado()
            nuevo_articulo.Nombre =  Nombre
            nuevo_articulo.Telefono = Telefono
            nuevo_articulo.Correo = Correo
            nuevo_articulo.Lugar = Lugar
            nuevo_articulo.Precio = Precio
            nuevo_articulo.Descripcion = Descripcion
            nuevo_articulo.save()
            return render(request, 'mercado.html')
 

    else:    
        return render(request, 'mercado.html')